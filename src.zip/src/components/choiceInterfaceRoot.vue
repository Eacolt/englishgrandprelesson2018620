<template>
    <router-view></router-view>
</template>

<script>
    export default {
        name: "choice-interface-root"
    }
</script>

